package Main;

public class RitaRepulsa extends Enemic {

	public RitaRepulsa (String nom, PowerRanger nem) {
		super(nom, nem);
	}

	
}
