package Main;

public class ArmaAncestral {
	public String instruccions = "LOREM IPSUM";
	
	public String alliberarPoder() {
		return "El poder d'aquesta arma s'ha alliberat correctament..";
	}
}
