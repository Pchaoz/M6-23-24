package Main;

public interface HeroiEquipat {

	String equipar();
	double getPoder();
	void setPoder(double poder);
	String getNomMecha();
	
}
