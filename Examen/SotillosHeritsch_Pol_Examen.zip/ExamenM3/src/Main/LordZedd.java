package Main;

public class LordZedd extends Enemic {

	public LordZedd(String nom, PowerRanger nemesis) {
		super(nom, nemesis);
	}

}
