package Main;

public enum TipusEnemic {
	RitaRepulsa, LordZedd
}
