package Main;

public enum Color {
	VERMELL, GROC, ROSA, VERD, BLAU, NEGRE
}
