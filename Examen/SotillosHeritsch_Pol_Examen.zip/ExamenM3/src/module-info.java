module ExamenM3 {
	requires java.desktop;
	requires java.base;
	requires java.sql;
	requires mysql.connector.java;
}