package Observer;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class ClasseQueEscucha implements PropertyChangeListener {

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		
		//HACER LO NECESARIO AQUI EVT TIENE TODO EL EVENTO TANTO EL VALOR ANTIGUO COMO NUEVO COMO NOMBRE DEL MISMO
	}

}
