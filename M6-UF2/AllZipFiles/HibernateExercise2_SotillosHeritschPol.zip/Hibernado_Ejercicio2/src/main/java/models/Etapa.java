package models;

public enum Etapa {
	Egg, Baby, Kid, Young, Adult
}
