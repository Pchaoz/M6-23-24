package Models;

public enum Recurs {
	food, tools, materials
}
