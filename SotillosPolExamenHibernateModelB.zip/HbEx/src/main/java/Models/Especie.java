package Models;

public enum Especie {

	human, furry, reptilian
}
