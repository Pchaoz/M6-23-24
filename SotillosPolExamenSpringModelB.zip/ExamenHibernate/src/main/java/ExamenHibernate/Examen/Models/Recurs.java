package ExamenHibernate.Examen.Models;

public enum Recurs {
	food, tools, materials
}
