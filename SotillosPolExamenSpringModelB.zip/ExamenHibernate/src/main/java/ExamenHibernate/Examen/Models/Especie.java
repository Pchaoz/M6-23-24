package ExamenHibernate.Examen.Models;

public enum Especie {

	human, furry, reptilian
}
