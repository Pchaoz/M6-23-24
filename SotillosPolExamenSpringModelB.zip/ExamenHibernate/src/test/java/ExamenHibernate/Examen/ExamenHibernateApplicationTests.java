package ExamenHibernate.Examen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
