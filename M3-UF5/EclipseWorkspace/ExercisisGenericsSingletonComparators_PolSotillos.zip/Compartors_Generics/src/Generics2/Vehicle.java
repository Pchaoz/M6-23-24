package Generics2;

public interface Vehicle {

}
